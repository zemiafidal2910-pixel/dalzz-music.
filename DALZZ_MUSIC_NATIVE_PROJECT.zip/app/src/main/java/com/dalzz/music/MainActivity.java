package com.dalzz.music;

import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.media.MediaPlayer;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private final String API = "https://dalzz-music.dalzz6831.workers.dev/api/music";
    private LinearLayout list;
    private TextView status;
    private MediaPlayer player;
    private String currentAudio = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8,13,11));
        getWindow().setNavigationBarColor(Color.rgb(8,13,11));
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitAll().build());

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(20, 28, 20, 16);
        page.setBackgroundColor(Color.rgb(8,13,11));

        TextView title = new TextView(this);
        title.setText("DALZZ MUSIC");
        title.setTextColor(Color.rgb(32,232,121));
        title.setTextSize(26);
        title.setTypeface(null, Typeface.BOLD);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Discover your sound");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(13);
        page.addView(subtitle);

        status = new TextView(this);
        status.setText("Memuat musik...");
        status.setTextColor(Color.LTGRAY);
        status.setPadding(0, 20, 0, 12);
        page.addView(status);

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(page);
        loadMusic();
    }

    private void loadMusic() {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(API).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
            StringBuilder out = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) out.append(line);
            r.close();
            c.disconnect();

            JSONObject root = new JSONObject(out.toString());
            JSONArray tracks = root.optJSONArray("tracks");
            if (tracks == null) tracks = root.optJSONArray("data");
            list.removeAllViews();

            if (tracks == null || tracks.length() == 0) {
                status.setText("Belum ada lagu yang tersedia.");
                return;
            }

            status.setText("Popular music · " + tracks.length() + " lagu");
            for (int i = 0; i < tracks.length(); i++) {
                JSONObject t = tracks.getJSONObject(i);
                final String name = t.optString("title", "Unknown title");
                final String artist = t.optString("artist", "Unknown artist");
                final String audio = t.optString("audio", "");
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(16, 14, 16, 14);
                card.setBackgroundColor(Color.rgb(20,31,26));
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
                cp.setMargins(0, 0, 0, 10);
                list.addView(card, cp);

                TextView song = new TextView(this);
                song.setText(name);
                song.setTextColor(Color.WHITE);
                song.setTextSize(16);
                song.setTypeface(null, Typeface.BOLD);
                card.addView(song);

                TextView by = new TextView(this);
                by.setText(artist);
                by.setTextColor(Color.LTGRAY);
                by.setTextSize(13);
                card.addView(by);

                TextView play = new TextView(this);
                play.setText("▶  Putar");
                play.setTextColor(Color.rgb(32,232,121));
                play.setTextSize(14);
                play.setPadding(0, 12, 0, 0);
                card.addView(play);
                card.setOnClickListener(v -> playTrack(audio, name));
            }
        } catch (Exception e) {
            status.setText("Gagal memuat lagu. Periksa koneksi lalu coba lagi.");
        }
    }

    private void playTrack(String audio, String name) {
        if (audio == null || audio.isEmpty()) {
            Toast.makeText(this, "Link audio tidak tersedia.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            if (player != null) { player.release(); player = null; }
            status.setText("Memuat: " + name);
            player = new MediaPlayer();
            player.setDataSource(audio);
            player.setOnPreparedListener(mp -> {
                mp.start();
                status.setText("Sedang diputar: " + name);
            });
            player.setOnErrorListener((mp, what, extra) -> {
                status.setText("Audio tidak dapat diputar.");
                return true;
            });
            player.prepareAsync();
        } catch (Exception e) {
            status.setText("Gagal memutar audio.");
        }
    }

    @Override protected void onDestroy() {
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }
}
